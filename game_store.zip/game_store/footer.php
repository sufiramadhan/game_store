 <footer>
       <p>&#169 Game Store <i class="fab fa-accusoft"></i> 2022</p>
</footer>